import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;

public class JImageDisplay extends JComponent {
    private BufferedImage image;
    
    public JImageDisplay(int width, int height) {
        // TODO
    }
    
    protected void paintComponent(Graphics g) {
        // TODO
    }
    
    public void clearImage() {
        // TODO
    }
    
    public void drawPixel(int x, int y, int rgbColor) {
        // TODO
    }
}
